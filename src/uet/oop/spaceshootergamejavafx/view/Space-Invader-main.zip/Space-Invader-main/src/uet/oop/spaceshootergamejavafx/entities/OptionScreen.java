package uet.oop.spaceshootergamejavafx.entities;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
// import javafx.scene.media.MediaPlayer; // Không cần import MediaPlayer trực tiếp nữa nếu dùng static method
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class OptionScreen {

    private static boolean backgroundMusicEnabled = true;
    private static double musicVolume = 0.5;

    // Không cần tham số MediaPlayer nữa nếu gọi phương thức static của MainMenu
    public void display(Stage primaryStage, Scene previousScene /*, MediaPlayer anyPlayer */) {
        VBox mainLayout = new VBox(30);
        mainLayout.setAlignment(Pos.CENTER);
        mainLayout.setPadding(new Insets(50));

        Label titleLabel = new Label("GAME OPTIONS");
        titleLabel.setFont(Font.font("Arial", 36));
        titleLabel.setTextFill(Color.BLACK);

        GridPane optionsGrid = new GridPane();
        optionsGrid.setAlignment(Pos.CENTER);
        optionsGrid.setHgap(20);
        optionsGrid.setVgap(15);

        Label musicEnabledLabel = new Label("Enable Music:");
        musicEnabledLabel.setFont(Font.font("Arial", 18));
        CheckBox musicCheckBox = new CheckBox();
        musicCheckBox.setSelected(backgroundMusicEnabled);
        musicCheckBox.setOnAction(e -> {
            backgroundMusicEnabled = musicCheckBox.isSelected();
            System.out.println("Music enabled: " + backgroundMusicEnabled);
            MainMenu.updateGlobalMusicState(); // Gọi phương thức static của MainMenu
        });

        Label volumeLabel = new Label("Music Volume:");
        volumeLabel.setFont(Font.font("Arial", 18));
        Slider volumeSlider = new Slider(0, 1, musicVolume);
        volumeSlider.setShowTickLabels(true);
        volumeSlider.setShowTickMarks(true);
        volumeSlider.setMajorTickUnit(0.25);
        volumeSlider.setPrefWidth(200);
        volumeSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            musicVolume = newVal.doubleValue();
            System.out.println("Music volume set to: " + String.format("%.2f", musicVolume));
            MainMenu.updateGlobalMusicState(); // Gọi phương thức static của MainMenu
        });

        optionsGrid.add(musicEnabledLabel, 0, 0);
        optionsGrid.add(musicCheckBox, 1, 0);
        optionsGrid.add(volumeLabel, 0, 1);
        optionsGrid.add(volumeSlider, 1, 1);

        Button backButton = new Button("Back to Main Menu");
        backButton.setFont(Font.font("Arial", 18));
        backButton.setPrefWidth(250);
        backButton.setPrefHeight(50);
        backButton.setOnAction(e -> {
            primaryStage.setScene(previousScene);
            primaryStage.setTitle("T Project: Space Invader");
            // MainMenu.updateGlobalMusicState(); // Không cần thiết nếu listener của sceneProperty trong MainMenu đã xử lý
        });

        mainLayout.getChildren().addAll(titleLabel, optionsGrid, backButton);

        Scene optionScene = new Scene(mainLayout, primaryStage.getWidth(), primaryStage.getHeight());
        primaryStage.setScene(optionScene);
        primaryStage.setTitle("Game Options");
    }

    public static boolean isBackgroundMusicEnabled() {
        return backgroundMusicEnabled;
    }

    public static double getMusicVolume() {
        return musicVolume;
    }
}