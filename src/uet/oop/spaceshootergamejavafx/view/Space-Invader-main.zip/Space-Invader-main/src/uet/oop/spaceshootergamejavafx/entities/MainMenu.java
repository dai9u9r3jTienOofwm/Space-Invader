package uet.oop.spaceshootergamejavafx.entities;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import java.net.URL;

public class MainMenu extends Application {

    private static MediaPlayer globalMusicPlayer;
    private static final String GLOBAL_MUSIC_FILE_PATH = "/res/audio/music.mp3";
    private static final String MENU_BACKGROUND_IMAGE_PATH = "/res/Menu.png";

    public static void initializeGlobalMusic() {
        if (globalMusicPlayer != null) { // Chỉ khởi tạo một lần
            return;
        }
        try {
            URL musicResource = MainMenu.class.getResource(GLOBAL_MUSIC_FILE_PATH); // Dùng MainMenu.class
            if (musicResource == null) {
                System.err.println("LỖI: Không tìm thấy file nhạc nền: " + GLOBAL_MUSIC_FILE_PATH);
                return;
            }
            Media globalMedia = new Media(musicResource.toExternalForm());
            globalMusicPlayer = new MediaPlayer(globalMedia);
            globalMusicPlayer.setCycleCount(MediaPlayer.INDEFINITE);
            // Việc phát và đặt âm lượng sẽ do updateGlobalMusicState() xử lý
        } catch (Exception e) {
            System.err.println("Lỗi trong quá trình tải nhạc nền: " + e.getMessage());
            e.printStackTrace();
            globalMusicPlayer = null;
        }
    }

    // Phương thức static để cập nhật trạng thái nhạc từ bất cứ đâu
    public static void updateGlobalMusicState() {
        if (globalMusicPlayer != null) {
            if (OptionScreen.isBackgroundMusicEnabled()) {
                globalMusicPlayer.setVolume(OptionScreen.getMusicVolume());
                if (globalMusicPlayer.getStatus() != MediaPlayer.Status.PLAYING) {
                    globalMusicPlayer.play();
                }
            } else {
                globalMusicPlayer.pause();
            }
        }
    }

    @Override
    public void init() throws Exception {
        super.init();
        // Khởi tạo nhạc ngay trong phương thức init() của Application
        // để nó sẵn sàng trước khi start() được gọi
        initializeGlobalMusic();
    }

    private Scene mainMenuScene; // Biến để lưu trữ Scene của MainMenu
    @Override
    public void start(Stage primaryStage) {
        // VBox chứa các nút
        VBox menuBox = new VBox(20);
        menuBox.setAlignment(Pos.CENTER_RIGHT); // căn phải bên trong VBox

        // Nút
        Button startButton = new Button();
        Button optionButton = new Button();
        Button exitButton = new Button();

        // Style cho nút (trong suốt + font)
        String buttonStyle = "-fx-background-color: rgba(0, 0, 0, 0.4); -fx-text-fill: white;";
        Font font = Font.font("Arial", 24);
        for (Button button : new Button[]{startButton, optionButton, exitButton}) {
            button.setStyle(buttonStyle);
            button.setFont(font);
            button.setPrefWidth(200);
            button.setPrefHeight(60);
        }

        startButton.setOnAction(e -> {
            // KHÔNG DỪNG NHẠC Ở ĐÂY NỮA
            // updateGlobalMusicState(); // Đảm bảo nhạc phát đúng trạng thái nếu có thay đổi ngầm
            try {
                // Giả sử SpaceShooter không tự quản lý nhạc nền này
                new SpaceShooter().start(primaryStage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        optionButton.setOnAction(e -> {
            OptionScreen optionScreen = new OptionScreen();
            // Truyền globalMusicPlayer (hoặc không cần truyền nếu OptionScreen gọi static method)
            optionScreen.display(primaryStage, mainMenuScene /*, globalMusicPlayer // Không cần thiết nếu OptionScreen dùng static method */);
        });

        exitButton.setOnAction(e -> {
            // DỪNG NHẠC KHI THOÁT GAME HOÀN TOÀN
            if (globalMusicPlayer != null) {
                globalMusicPlayer.stop();
                // dispose() sẽ được gọi trong phương thức stop() của Application
            }
            primaryStage.close();
        });

        menuBox.getChildren().addAll(startButton, optionButton, exitButton);

        AnchorPane root = new AnchorPane();
        URL bgImageResource = getClass().getResource(MENU_BACKGROUND_IMAGE_PATH);
        if (bgImageResource != null) {
            BackgroundImage bg = new BackgroundImage(
                    new Image(bgImageResource.toExternalForm(), 1000, 640, false, true),
                    BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
            root.setBackground(new Background(bg));
        } else {
            System.err.println("LỖI: Không tìm thấy ảnh nền menu: " + MENU_BACKGROUND_IMAGE_PATH);
        }
        root.getChildren().add(menuBox);

        AnchorPane.setTopAnchor(menuBox, 280.0);
        AnchorPane.setRightAnchor(menuBox, 110.0);

        mainMenuScene = new Scene(root, 1000, 640);
        primaryStage.setScene(mainMenuScene);
        primaryStage.setTitle("T Project: Space Invader");

        // Cập nhật trạng thái nhạc khi scene của stage thay đổi (ví dụ quay lại từ Option)
        // hoặc khi stage được hiển thị lần đầu.
        primaryStage.sceneProperty().addListener((obs, oldScene, newScene) -> {
            // Cập nhật nhạc bất kể scene nào, vì nhạc chạy xuyên suốt
             updateGlobalMusicState();
        });
        primaryStage.setOnShown(event -> updateGlobalMusicState()); // Đảm bảo nhạc phát khi hiển thị lần đầu


        // primaryStage.setOnCloseRequest sẽ được xử lý bởi phương thức stop() của Application
        primaryStage.show();
        updateGlobalMusicState(); // Phát nhạc lần đầu (quan trọng)
    }

    @Override
    public void stop() throws Exception {
        // Phương thức này được gọi khi ứng dụng JavaFX đóng
        // (ví dụ khi primaryStage.close() được gọi hoặc người dùng đóng cửa sổ)
        if (globalMusicPlayer != null) {
            globalMusicPlayer.stop();
            globalMusicPlayer.dispose();
        }
        super.stop();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
