package uet.oop.spaceshootergamejavafx.entities;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

/**
 * PowerUp entity with sprite support.
 */
public class PowerUp extends GameObject {

    public static final int WIDTH = 20;
    public static final int HEIGHT = 20;
    private static final double SPEED = 200;

    private boolean dead;
    private Image image;

    /**
     * Constructs a PowerUp at the given position.
     * @param x initial X position
     * @param y initial Y position
     */
    public PowerUp(double x, double y) {
        super(x, y, WIDTH, HEIGHT);
        dead = false;

        try {
            // Adjust the path based on your project structure
            var resource = getClass().getResource("/res/powerItem.png");
            if (resource == null) {
                throw new RuntimeException("Image not found: /res/powerItem.png");
            }
            image = new Image(resource.toExternalForm());
        } catch (Exception e) {
            System.err.println("Failed to load power-up image: " + e.getMessage());
            image = null;
        }
    }

    @Override
    public void update(float deltaTime) {
        setY(getY() + SPEED * deltaTime);  // Falling downwards
        if (getY() > 600) {
            setDead(true);
        }
    }

    @Override
    public void render(GraphicsContext gc) {
        if (image != null) {
            gc.drawImage(image, getX() - getWidth() / 2, getY() - getHeight() / 2, getWidth(), getHeight());
        } else {
            gc.setFill(javafx.scene.paint.Color.YELLOW);
            gc.fillRect(getX() - getWidth() / 2, getY() - getHeight() / 2, getWidth(), getHeight());
        }
    }

    @Override
    public double getWidth() {
        return WIDTH;
    }

    @Override
    public double getHeight() {
        return HEIGHT;
    }

    @Override
    public boolean isDead() {
        return dead;
    }

    public void setDead(boolean dead) {
        this.dead = dead;
    }
}
