package uet.oop.spaceshootergamejavafx.entities;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import uet.oop.spaceshootergamejavafx.entities.*;

import java.util.ArrayList;
import java.util.List;

public class SpaceShooter extends Application {

    private static final int WIDTH = 480;
    private static final int HEIGHT = 640;

    private static GraphicsContext gc;

    private static List<Bullet> playerBullets = new ArrayList<>();
    private static List<EnemyBullet> enemyBullets = new ArrayList<>();
    private static List<EnemyType1> enemiesType1 = new ArrayList<>();
    private static List<EnemyType2> enemiesType2 = new ArrayList<>();
    private static List<EnemyBullet> bossBullets = new ArrayList<>();
    private static List<PowerUp> powerUps = new ArrayList<>();


    // Thêm ở đầu class
    private double enemySpawnTimer = 0;
    private static final double ENEMY_SPAWN_INTERVAL = 0.8; // giây
    private int enemiesKilled = 0;
    private static final int BOSS_TRIGGER_KILL = 30;        // hạ 30 địch thì xuất boss
    private AnimationTimer gameLoop; // thêm dòng này


    // ở đầu class SpaceShooter
    private Image bgImage;
    private double bgY1 = 0, bgY2 = -HEIGHT;   // hai tấm ảnh xếp chồng để cuộn
    private static final double BG_SCROLL_SPEED = 50; // px/s

    private Player player;
    private static BossEnemy boss;
    private boolean bossSpawned = false;

    public static int getHEIGHT() {
        return HEIGHT;
    }

    public static int getWIDTH() {
        return WIDTH;
    }

    public static List<Bullet> getPlayerBullets() {
        return playerBullets;
    }

    public static List<EnemyBullet> getEnemyBullets() {
        return enemyBullets;
    }

    public static List<EnemyType1> getEnemiesType1() {
        return enemiesType1;
    }

    public static List<EnemyType2> getEnemiesType2() {
        return enemiesType2;
    }

    public static BossEnemy getBoss() {
        return boss;
    }

    public static List<EnemyBullet> getBossBullets() {
        return bossBullets;
    }

    private void showGameOver(Stage stage) {
        StackPane root = new StackPane();
        root.setStyle("-fx-background-color: black");

        Label label = new Label("GAME OVER");
        label.setStyle("-fx-text-fill: red; -fx-font-size: 48");

        root.getChildren().add(label);

        Scene scene = new Scene(root, WIDTH, HEIGHT);
        stage.setScene(scene);
    }

    private void showGameWin(Stage stage) {
        StackPane root = new StackPane();
        root.setStyle("-fx-background-color: black");

        Label label = new Label("YOU WIN!");
        label.setStyle("-fx-text-fill: lime; -fx-font-size: 48");

        root.getChildren().add(label);

        Scene scene = new Scene(root, WIDTH, HEIGHT);
        stage.setScene(scene);
    }



    @Override
    public void start(Stage stage) {
        Pane root = new Pane();
        Canvas canvas = new Canvas(WIDTH, HEIGHT);
        gc = canvas.getGraphicsContext2D();
        root.getChildren().add(canvas);

        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Space Shooter");
        stage.show();

        player = new Player(WIDTH / 2.0 - 15, HEIGHT - 60);

        var url = getClass().getResource("/res/background-near.png");
        if (url == null) throw new RuntimeException("Missing background!");
        bgImage = new Image(url.toExternalForm());


        scene.setOnKeyPressed(e -> player.handleKeyPress(e.getCode()));
        scene.setOnKeyReleased(e -> player.handleKeyRelease(e.getCode()));

        gameLoop = new AnimationTimer() {
            private long lastTime = 0;

            @Override
            public void handle(long now) {
                if (lastTime == 0) {
                    lastTime = now;
                    return;
                }
                float deltaTime = (now - lastTime) / 1e9f;
                lastTime = now;

                update(deltaTime);
                render();
            }
        };
        gameLoop.start();
    }

    private void update(float deltaTime) {
        for (EnemyBullet bb : bossBullets) {
            bb.update(deltaTime);
        }
        bossBullets.removeIf(GameObject::isDead);

        bgY1 += BG_SCROLL_SPEED * deltaTime;
        bgY2 += BG_SCROLL_SPEED * deltaTime;

        if (bgY1 >= HEIGHT) bgY1 = bgY2 - HEIGHT;
        if (bgY2 >= HEIGHT) bgY2 = bgY1 - HEIGHT;

        enemySpawnTimer += deltaTime;

        if (!bossSpawned && enemySpawnTimer >= ENEMY_SPAWN_INTERVAL) {
            enemySpawnTimer = 0;

            double r = Math.random();
            if (r < 0.8) {                       // 80 % spawn EnemyType1
                enemiesType1.add(
                        new EnemyType1(Math.random() * (WIDTH - 30), -30));
            } else {                             // 20 % spawn EnemyType2
                enemiesType2.add(
                        new EnemyType2(0, 50, (int)(Math.random() * (WIDTH - 40))));
            }
        }
        // 3% cơ hội mỗi giây
        if (Math.random() < 0.1 * deltaTime) {
            double x = 20 + Math.random() * (WIDTH - 40);
            powerUps.add(new PowerUp(x, -20));
        }

        powerUps.forEach(p -> p.update(deltaTime));
        powerUps.removeIf(GameObject::isDead);

        player.update(deltaTime);

        playerBullets.forEach(b -> b.update(deltaTime));
        enemyBullets.forEach(b -> b.update(deltaTime));
        enemiesType1.forEach(e -> e.update(deltaTime));
        enemiesType2.forEach(e -> e.update(deltaTime));

        if (boss != null) {
            boss.update(deltaTime);
        }

        playerBullets.removeIf(GameObject::isDead);
        enemyBullets.removeIf(GameObject::isDead);
        enemiesType1.removeIf(GameObject::isDead);
        enemiesType2.removeIf(GameObject::isDead);
        if (boss != null && boss.isDead() && bossSpawned) {
            System.out.println("You Win!");
            stopGame();
            showGameWin((Stage) gc.getCanvas().getScene().getWindow());
            boss = null;  // chuyển dòng này xuống sau khi show win
            return;
        }

        checkCollisions();

        for (EnemyBullet bullet : enemyBullets) {
            bullet.update(deltaTime);
            if (player.getBounds().intersects(bullet.getBounds())) {
                player.takeDamage(); // giảm máu
                bullet.setDead(true); // xóa đạn
                System.out.println("Player hit! Health: " + player.getHealth());
            }
        }


        if (!bossSpawned && enemiesKilled >= BOSS_TRIGGER_KILL) {
            boss = new BossEnemy(WIDTH / 2.0 - 25, -100);
            bossSpawned = true;
            System.out.println("Boss spawned!");
        }

        if (player.getHealth() <= 0) {
            System.out.println("Game Over!");
            stopGame();
            showGameOver((Stage) gc.getCanvas().getScene().getWindow());
            return;
        }

        if (boss != null && boss.isDead() && bossSpawned) {
            System.out.println("You Win!");
            stopGame();
            showGameWin((Stage) gc.getCanvas().getScene().getWindow());
            return;
        }


    }

    private void checkCollisions() {
        for (Bullet bullet : playerBullets) {
            for (EnemyType1 enemy : enemiesType1) {
                if (bullet.getBounds().intersects(enemy.getBounds())) {
                    bullet.setDead(true);
                    enemy.takeDamage(player.getPowerLevel());
                    if (enemy.health <= 0) {
                        enemy.setDead(true);
                        enemiesKilled++;
                    }
                }
            }

            for (EnemyType2 enemy : enemiesType2) {
                if (bullet.getBounds().intersects(enemy.getBounds())) {
                    bullet.setDead(true);
                    enemy.takeDamage(player.getPowerLevel());
                    if (enemy.getHealth() <= 0) {
                        enemy.setDead(true);
                        enemiesKilled++;
                    }
                }
            }
            if (boss != null && bullet.getBounds().intersects(boss.getBounds())) {
                bullet.setDead(true);
                boss.takeDamage(player.getPowerLevel());
            }

        }

        for (PowerUp pu : powerUps) {
            if (pu.getBounds().intersects(player.getBounds())) {
                player.addPower();      // hoặc player.addHealth();
                pu.setDead(true);
            }
        }


        for (EnemyBullet eb : enemyBullets) {
            if (eb.getBounds().intersects(player.getBounds())) {
                eb.setDead(true);
                player.takeDamage();
            }
        }

        for (EnemyType2 enemy : enemiesType2) {
            if (player.getBounds().intersects(enemy.getBounds())) {
                player.setHealth(0);
            }
        }

        for (EnemyType1 enemy : enemiesType1) {
            if (player.getBounds().intersects(enemy.getBounds())) {
                player.setHealth(0);
            }
        }

        if (boss != null && player.getBounds().intersects(boss.getBounds())) {
            player.setHealth(0);
        }
    }

    private void render() {
        gc.clearRect(0, 0, WIDTH, HEIGHT);

        gc.drawImage(bgImage, 0, bgY1, WIDTH, HEIGHT);
        gc.drawImage(bgImage, 0, bgY2, WIDTH, HEIGHT);
        powerUps.forEach(p -> p.render(gc));

        player.render(gc);
        for (EnemyBullet bb : bossBullets) {
            bb.render(gc);
        }
        playerBullets.forEach(b -> b.render(gc));
        enemyBullets.forEach(b -> b.render(gc));
        enemiesType1.forEach(e -> e.render(gc));
        enemiesType2.forEach(e -> e.render(gc));
        if (boss != null) {
            boss.render(gc);
        }
    }

    private void stopGame() {
        if (gameLoop != null) {
            gameLoop.stop();
        }
    }


    public static void main(String[] args) {
        launch();
    }
}
