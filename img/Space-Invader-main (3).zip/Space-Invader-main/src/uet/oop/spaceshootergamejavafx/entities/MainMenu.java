package uet.oop.spaceshootergamejavafx.entities;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class MainMenu extends Application {

    @Override
    public void start(Stage primaryStage) {
        // VBox chứa các nút
        VBox menuBox = new VBox(20);
        menuBox.setAlignment(Pos.CENTER_RIGHT); // căn phải bên trong VBox

        // Nút
        Button startButton = new Button();
        Button optionButton = new Button();
        Button exitButton = new Button();

        // Style cho nút (trong suốt + font)
        String buttonStyle = "-fx-background-color: rgba(0, 0, 0, 0.4); -fx-text-fill: white;";
        Font font = Font.font("Arial", 24);
        for (Button button : new Button[]{startButton, optionButton, exitButton}) {
            button.setStyle(buttonStyle);
            button.setFont(font);
            button.setPrefWidth(200);
            button.setPrefHeight(60);
        }

        // Xử lý sự kiện
        startButton.setOnAction(e -> {
            try {
                new SpaceShooter().start(primaryStage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        optionButton.setOnAction(e -> System.out.println("Option pressed"));
        exitButton.setOnAction(e -> primaryStage.close());

        menuBox.getChildren().addAll(startButton, optionButton, exitButton);

        // Background
        BackgroundImage bg = new BackgroundImage(
                new Image(getClass().getResource("/res/Menu.png").toExternalForm(), 1000, 640, false, true),
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
        Background background = new Background(bg);

        // AnchorPane cho layout tự do
        AnchorPane root = new AnchorPane();
        root.setBackground(background);
        root.getChildren().add(menuBox);

        // Căn menu sang phải + giữa chiều cao
        AnchorPane.setTopAnchor(menuBox, 280.0);  // chỉnh xuống một chút
        AnchorPane.setRightAnchor(menuBox, 110.0); // lề phải

        Scene scene = new Scene(root, 1000, 640);
        primaryStage.setScene(scene);
        primaryStage.setTitle("T Project: Space Invader");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
