package uet.oop.spaceshootergamejavafx.entities;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import java.net.URL;

/**
 * Main menu screen for the Space Shooter game.
 * Provides options to start the game, adjust settings, or exit.
 */
public class MainMenu extends Application {

    /**
     * The global music player that handles background music across scenes.
     */
    private static MediaPlayer globalMusicPlayer;

    private static final String GLOBAL_MUSIC_FILE_PATH = "/res/audio/music.mp3";
    private static final String MENU_BACKGROUND_IMAGE_PATH = "/res/Menu.png";

    /**
     * Initializes the global background music player if it hasn't been created yet.
     * This method should be called once at the start of the application.
     */
    public static void initializeGlobalMusic() {
        if (globalMusicPlayer != null) {
            return;
        }
        try {
            URL musicResource = MainMenu.class.getResource(GLOBAL_MUSIC_FILE_PATH);
            if (musicResource == null) {
                System.err.println("ERROR: Background music file not found: " + GLOBAL_MUSIC_FILE_PATH);
                return;
            }
            Media globalMedia = new Media(musicResource.toExternalForm());
            globalMusicPlayer = new MediaPlayer(globalMedia);
            globalMusicPlayer.setCycleCount(MediaPlayer.INDEFINITE);
        } catch (Exception e) {
            System.err.println("Error loading background music: " + e.getMessage());
            e.printStackTrace();
            globalMusicPlayer = null;
        }
    }

    /**
     * Updates the global background music playback state based on user settings.
     * This method is static and can be called from anywhere.
     */
    public static void updateGlobalMusicState() {
        if (globalMusicPlayer != null) {
            if (OptionScreen.isBackgroundMusicEnabled()) {
                globalMusicPlayer.setVolume(OptionScreen.getMusicVolume());
                if (globalMusicPlayer.getStatus() != MediaPlayer.Status.PLAYING) {
                    globalMusicPlayer.play();
                }
            } else {
                globalMusicPlayer.pause();
            }
        }
    }

    @Override
    public void init() throws Exception {
        super.init();
        initializeGlobalMusic();
    }

    private Scene mainMenuScene;

    /**
     * Starts the JavaFX application by creating and displaying the main menu UI.
     *
     * @param primaryStage The main window of the application.
     */
    @Override
    public void start(Stage primaryStage) {
        VBox menuBox = new VBox(20);
        menuBox.setAlignment(Pos.CENTER_RIGHT);

        Button startButton = new Button();
        Button optionButton = new Button();
        Button exitButton = new Button();

        String buttonStyle = "-fx-background-color: rgba(0, 0, 0, 0.4); -fx-text-fill: white;";
        Font font = Font.font("Arial", 24);
        for (Button button : new Button[]{startButton, optionButton, exitButton}) {
            button.setStyle(buttonStyle);
            button.setFont(font);
            button.setPrefWidth(200);
            button.setPrefHeight(60);
        }

        startButton.setOnAction(e -> {
            try {
                new SpaceShooter().start(primaryStage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        optionButton.setOnAction(e -> {
            OptionScreen optionScreen = new OptionScreen();
            optionScreen.display(primaryStage, mainMenuScene);
        });

        exitButton.setOnAction(e -> {
            if (globalMusicPlayer != null) {
                globalMusicPlayer.stop();
            }
            primaryStage.close();
        });

        menuBox.getChildren().addAll(startButton, optionButton, exitButton);

        AnchorPane root = new AnchorPane();
        URL bgImageResource = getClass().getResource(MENU_BACKGROUND_IMAGE_PATH);
        if (bgImageResource != null) {
            BackgroundImage bg = new BackgroundImage(
                    new Image(bgImageResource.toExternalForm(), 1000, 640, false, true),
                    BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
            root.setBackground(new Background(bg));
        } else {
            System.err.println("ERROR: Menu background image not found: " + MENU_BACKGROUND_IMAGE_PATH);
        }
        root.getChildren().add(menuBox);

        AnchorPane.setTopAnchor(menuBox, 280.0);
        AnchorPane.setRightAnchor(menuBox, 110.0);

        mainMenuScene = new Scene(root, 1000, 640);
        primaryStage.setScene(mainMenuScene);
        primaryStage.setTitle("T Project: Space Invader");

        primaryStage.sceneProperty().addListener((obs, oldScene, newScene) -> {
            updateGlobalMusicState();
        });
        primaryStage.setOnShown(event -> updateGlobalMusicState());

        primaryStage.show();
        updateGlobalMusicState();
    }

    /**
     * Cleans up resources when the application is stopped.
     * This method is called automatically when the application exits.
     */
    @Override
    public void stop() throws Exception {
        if (globalMusicPlayer != null) {
            globalMusicPlayer.stop();
            globalMusicPlayer.dispose();
        }
        super.stop();
    }

    /**
     * Main entry point of the JavaFX application.
     *
     * @param args Command-line arguments.
     */
    public static void main(String[] args) {
        launch(args);
    }
}
