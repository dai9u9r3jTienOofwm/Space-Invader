package uet.oop.spaceshootergamejavafx.entities;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * Represents the option screen for configuring game settings such as background music and volume.
 */
public class OptionScreen {

    /**
     * Indicates whether background music is enabled.
     */
    private static boolean backgroundMusicEnabled = true;

    /**
     * The current background music volume (0.0 to 1.0).
     */
    private static double musicVolume = 0.5;

    /**
     * Displays the options screen.
     *
     * @param primaryStage The main stage where the scene will be set.
     * @param previousScene The previous scene (main menu) to return to.
     */
    public void display(Stage primaryStage, Scene previousScene) {
        VBox mainLayout = new VBox(30);
        mainLayout.setAlignment(Pos.CENTER);
        mainLayout.setPadding(new Insets(50));

        Label titleLabel = new Label("GAME OPTIONS");
        titleLabel.setFont(Font.font("Arial", 36));
        titleLabel.setTextFill(Color.BLACK);

        GridPane optionsGrid = new GridPane();
        optionsGrid.setAlignment(Pos.CENTER);
        optionsGrid.setHgap(20);
        optionsGrid.setVgap(15);

        Label musicEnabledLabel = new Label("Enable Music:");
        musicEnabledLabel.setFont(Font.font("Arial", 18));

        CheckBox musicCheckBox = new CheckBox();
        musicCheckBox.setSelected(backgroundMusicEnabled);
        musicCheckBox.setOnAction(e -> {
            backgroundMusicEnabled = musicCheckBox.isSelected();
            System.out.println("Music enabled: " + backgroundMusicEnabled);
            MainMenu.updateGlobalMusicState();
        });

        Label volumeLabel = new Label("Music Volume:");
        volumeLabel.setFont(Font.font("Arial", 18));

        Slider volumeSlider = new Slider(0, 1, musicVolume);
        volumeSlider.setShowTickLabels(true);
        volumeSlider.setShowTickMarks(true);
        volumeSlider.setMajorTickUnit(0.25);
        volumeSlider.setPrefWidth(200);
        volumeSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            musicVolume = newVal.doubleValue();
            System.out.println("Music volume set to: " + String.format("%.2f", musicVolume));
            MainMenu.updateGlobalMusicState();
        });

        optionsGrid.add(musicEnabledLabel, 0, 0);
        optionsGrid.add(musicCheckBox, 1, 0);
        optionsGrid.add(volumeLabel, 0, 1);
        optionsGrid.add(volumeSlider, 1, 1);

        Button backButton = new Button("Back to Main Menu");
        backButton.setFont(Font.font("Arial", 18));
        backButton.setPrefWidth(250);
        backButton.setPrefHeight(50);
        backButton.setOnAction(e -> {
            primaryStage.setScene(previousScene);
            primaryStage.setTitle("T Project: Space Invader");
        });

        mainLayout.getChildren().addAll(titleLabel, optionsGrid, backButton);

        Scene optionScene = new Scene(mainLayout, primaryStage.getWidth(), primaryStage.getHeight());
        primaryStage.setScene(optionScene);
        primaryStage.setTitle("Game Options");
    }

    /**
     * Returns whether background music is enabled.
     *
     * @return true if music is enabled, false otherwise.
     */
    public static boolean isBackgroundMusicEnabled() {
        return backgroundMusicEnabled;
    }

    /**
     * Returns the current music volume.
     *
     * @return The music volume value (0.0 to 1.0).
     */
    public static double getMusicVolume() {
        return musicVolume;
    }
}
