package uet.oop.spaceshootergamejavafx.entities;

import javafx.animation.AnimationTimer;
import javafx.geometry.Point2D;
import java.util.List;

public class BulletTask {

    /* ======== 1. Player bullets ======== */

    private static final double SPACING = 8;   // khoảng cách ngang giữa các viên khi bắn nhiều

    /**
     * Bắn đạn cho người chơi tùy theo powerLevel
     *
     * @param bullets     list đạn của người chơi
     * @param position    tâm súng (thường là giữa thân máy bay)
     * @param direction   hướng bắn (ví dụ (0,-1) để bắn lên)
     * @param powerLevel  sức mạnh: <60 =1 đạn; 60–99 =2; ≥100 =3
     */
    public static void spamBullet(List<Bullet> bullets,
                                  Point2D position,
                                  Point2D direction,
                                  int powerLevel) {

        int count = powerLevel < 60 ? 1           // 1 viên
                : powerLevel < 100 ? 2          // 2 viên
                : 3;                            // 3 viên

        // Bắt đầu từ viên chính giữa rồi xòe sang hai bên
        double startX = position.getX() - (count - 1) * SPACING / 2.0;

        for (int i = 0; i < count; i++) {
            Point2D spawnPos = new Point2D(startX + i * SPACING, position.getY());
            createPlayerBullet(bullets, spawnPos, direction);
        }
    }

    private static void createPlayerBullet(List<Bullet> bullets,
                                           Point2D pos,
                                           Point2D dir) {
        Bullet b = new Bullet(pos, dir);
        bullets.add(b);
        addBulletToGame(b);
    }

    /* ======== 2. Enemy bullets ======== */

    /** Bắn một viên đạn cho kẻ địch theo hướng chỉ định */
    public static void spamEBullet(List<EnemyBullet> bullets,
                                   Point2D position,
                                   Point2D direction) {

        EnemyBullet eb = new EnemyBullet(position, direction);
        bullets.add(eb);
        addBulletToGame(eb);
    }

    /** Bắn đạn tỏa tròn quanh vị trí `position` với `bulletCount` viên */
    public static void spamRadialBullets(List<EnemyBullet> bullets,
                                         Point2D position,
                                         int bulletCount) {

        double step = 2 * Math.PI / bulletCount;
        for (int i = 0; i < bulletCount; i++) {
            double angle = i * step;
            Point2D dir = new Point2D(Math.cos(angle), Math.sin(angle));
            spamEBullet(bullets, position, dir);
        }
    }

    /**
     * Bắn đạn xoắn ốc (spiral) – mỗi `interval` mili-giây tạo 1 viên.
     * Dừng khi đủ `bulletCount`.
     */
    public static void spamSpiralBullets(List<EnemyBullet> bullets,
                                         Point2D position,
                                         int bulletCount,
                                         long intervalMs) {

        new AnimationTimer() {
            private long last = 0;
            private int spawned = 0;
            private double angle = 0;
            private final double step = 2 * Math.PI / bulletCount;

            @Override
            public void handle(long now) {
                if (last == 0 || now - last >= intervalMs * 1_000_000L) {
                    Point2D dir = new Point2D(Math.cos(angle), Math.sin(angle));
                    spamEBullet(bullets, position, dir);

                    angle += step;
                    spawned++;
                    last = now;

                    if (spawned >= bulletCount) stop();
                }
            }
        }.start();
    }

    /* ======== 3. Hook vào game-loop / manager ======== */

    private static void addBulletToGame(GameObject bullet) {
        // TODO: thay bằng lệnh add object vào hệ thống quản lý đối tượng của bạn
        System.out.printf("Bullet added (%.1f, %.1f)%n", bullet.getX(), bullet.getY());
    }
}
