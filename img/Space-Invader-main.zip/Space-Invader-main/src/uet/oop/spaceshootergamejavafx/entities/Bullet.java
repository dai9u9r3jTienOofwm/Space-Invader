package uet.oop.spaceshootergamejavafx.entities;

import javafx.geometry.Point2D;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;

import java.net.URL;
import java.util.Objects;

public class Bullet extends GameObject {

    public static final int WIDTH  = 4;
    public static final int HEIGHT = 8;
    private static final double SPEED = 300;         // px / s

    private static final Image SPRITE;

    static {  // tải ảnh 1 lần và chia sẻ cho mọi viên đạn
        URL url = Bullet.class.getResource("/res/player_bullet.png");
        if (url == null) {
            System.err.println("⚠️  Missing /res/player_bullet.png -> fallback rectangle");
            SPRITE = null;
        } else {
            SPRITE = new Image(url.toExternalForm());
        }
    }

    private final Point2D direction;   // đơn vị: (-1,0) trái, (0,-1) lên, v.v.
    private boolean dead = false;

    public Bullet(Point2D position, Point2D direction) {
        super(position.getX(), position.getY(), WIDTH, HEIGHT);
        this.direction = direction.normalize();       // bảo đảm độ dài = 1
    }

    @Override
    public void update(float dt) {
        setX(getX() + direction.getX() * SPEED * dt);
        setY(getY() + direction.getY() * SPEED * dt);

        // ra khỏi màn hình thì tự hủy
        if (getY() + HEIGHT < 0 || getY() > SpaceShooter.getHEIGHT() ||
                getX() + WIDTH  < 0 || getX() > SpaceShooter.getWIDTH()) {
            dead = true;
        }
    }

    @Override
    public void render(GraphicsContext gc) {
        if (SPRITE != null) {
            gc.drawImage(SPRITE, getX(), getY(), WIDTH, HEIGHT);
        } else {                        // fallback debug
            gc.setFill(Color.CYAN);
            gc.fillRect(getX(), getY(), WIDTH, HEIGHT);
        }
    }

    @Override public double  getWidth()  { return WIDTH;  }
    @Override public double  getHeight() { return HEIGHT; }
    @Override public boolean isDead()    { return dead;   }
    public   void            setDead(boolean dead) { this.dead = dead; }
}
